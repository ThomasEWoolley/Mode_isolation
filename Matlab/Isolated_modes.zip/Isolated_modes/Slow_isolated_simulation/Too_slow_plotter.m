ccc
load Too_slow

xs=x'*exp(par(3)*t);
T=repmat(t,200,1);
figure('units','normalized','Position',[0 0.1 1/2 1/3])
pcolor(T,xs,ue')
shading interp
xlabel('$t$')
ylabel('$L$')
set(gca,'FontSize',15)
axis([0 1.85e6 0 40])
export_fig('C:\Users\Thomas Woolley\Dropbox\Apps\Overleaf\Mode_isolation_Turing\Pictures\Slow_isolated_sim.png','-r300')
