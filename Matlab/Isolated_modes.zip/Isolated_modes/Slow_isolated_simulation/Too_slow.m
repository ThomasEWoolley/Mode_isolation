ccc
gamma=10;
beta=8.71;
r=2e-6;

par=[gamma beta r];%[c1 cn1 c2 c3 r]

% Spatial domain
x = linspace(0, 1, 200);

% Time domain
t = linspace(0, 2e6, 1e3);

options = odeset('RelTol',0.1,'AbsTol',0.1,'MaxStep',10); 
% Solve the PDE system
sol = pdepe(0, @(x, t, u, DuDx)pde_eqn(x, t, u, DuDx,par), @(x)pde_ic(x,par), @pde_bc, x, t,options);

% Extract solutions for u and v
ue = sol(:,:,1);
us = sol(:,:,2);
save Too_slow
%%
% Plot results
close all
pcolor(x, t, ue);
xlabel('Space, $x$');
ylabel('Time, $t$');
shading interp



function [c, f, s] = pde_eqn(x, t, u, DuDx,par)
% Schnakenberg PDE system equations
gamma=par(1);
beta=par(2);
r=par(3);

L=exp(r*t);

c = [1; 1];
f = [1;1e3].*DuDx/L^2;
% s = [gamma-beta-u(1)+u(1)^2*u(2)+1e-6*cos(99*x); beta-u(1)^2*u(2)+1e-6*cos(99*x)];
s = [gamma-beta-u(1)+u(1)^2*u(2)-r*u(1); beta-u(1)^2*u(2)-r*u(2)];
end

function u = pde_ic(x,par)
% Initial conditions
gamma=par(1);
beta=par(2);
r=par(3);

u0 = abs(gamma+0.1*randn); % Initial condition for u
v0 = abs(beta/gamma^2+0.1*randn); % Initial condition for v
u=[u0;v0];
end

function [pl, ql, pr, qr] = pde_bc(xl, ul, xr, ur, t)
% Boundary conditions (no flux conditions)
pl = [0; 0];
ql = [1; 1];
pr = [0; 0];
qr = [1; 1];
end
